﻿# FILE: src/frontend/pages/logs/page.py
from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path
from typing import Optional, List, Callable, Dict, Any

from PySide6.QtCore import Qt, QModelIndex
from PySide6.QtGui import QStandardItemModel, QStandardItem
from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QLabel,
    QHBoxLayout,
    QPushButton,
    QTableView,
    QAbstractItemView,
    QComboBox,
    QLineEdit,
    QFileDialog,
    QMessageBox,
    QTextEdit,
    QSplitter,
)

from app.paths import user_data_dir
from frontend.pages.campaigns.preview_dialog import CampaignPreviewDialog


class LogsPage(QWidget):
    HEADERS = [
        "ID",
        "시간",
        "캠페인ID",
        "배치ID",
        "채널",
        "수신자",
        "상태",
        "사유",
        "시도",
        "메시지길이",
        "이미지수",
    ]

    def __init__(
        self,
        *,
        logs_service,
        campaigns_service=None,
        on_reset_all: Optional[Callable[[], None]] = None,
    ) -> None:
        super().__init__()
        self.setObjectName("Page")

        self.logs_service = logs_service
        self.campaigns_service = campaigns_service
        self._on_reset_all = on_reset_all

        self._active_source: str = "DB"
        self._report_path: Optional[Path] = None
        self._report_rows: List[Dict[str, Any]] = []
        self._shown_rows: List[Dict[str, Any]] = []

        root = QVBoxLayout(self)
        root.setContentsMargins(18, 18, 18, 18)
        root.setSpacing(12)

        title = QLabel("로그/리포트")
        title.setObjectName("PageTitle")
        desc = QLabel("성공/실패/NOT_FOUND/사유/재시도 대상 관리 및 결과 내보내기 + 로그 파일/리포트 내용 확인.")
        desc.setObjectName("PageDesc")

        root.addWidget(title)
        root.addWidget(desc)

        report_row = QHBoxLayout()
        report_row.setSpacing(8)

        report_row.addWidget(QLabel("발송 리포트 파일"), 0)

        self.cbo_reports = QComboBox()
        self.cbo_reports.setMinimumWidth(520)

        self.btn_reports_refresh = QPushButton("리포트 새로고침")
        report_row.addWidget(self.cbo_reports, 1)
        report_row.addWidget(self.btn_reports_refresh, 0)

        root.addLayout(report_row)

        filter_row = QHBoxLayout()
        filter_row.setSpacing(8)

        self.cbo_status = QComboBox()
        self.cbo_status.addItem("전체", None)
        self.cbo_status.addItem("성공(SUCCESS)", "SUCCESS")
        self.cbo_status.addItem("실패(FAIL)", "FAIL")
        self.cbo_status.addItem("대화방없음(NOT_FOUND)", "NOT_FOUND")
        self.cbo_status.addItem("스킵(SKIP)", "SKIP")
        self.cbo_status.addItem("말미재시도예약(TAIL_RETRY_SCHEDULED)", "TAIL_RETRY_SCHEDULED")
        self.cbo_status.addItem("말미재시도성공(SUCCESS(TAIL_RETRY))", "SUCCESS(TAIL_RETRY)")
        self.cbo_status.addItem("말미재시도실패(FAIL(TAIL_RETRY))", "FAIL(TAIL_RETRY)")

        self.txt_keyword = QLineEdit()
        self.txt_keyword.setPlaceholderText("검색: 수신자/사유/채널 키워드")

        self.btn_refresh = QPushButton("새로고침")
        self.btn_fail_only = QPushButton("실패건 보기")
        self.btn_export = QPushButton("CSV 내보내기")

        filter_row.addWidget(QLabel("상태"))
        filter_row.addWidget(self.cbo_status, 0)
        filter_row.addWidget(self.txt_keyword, 1)
        filter_row.addWidget(self.btn_refresh)
        filter_row.addWidget(self.btn_fail_only)
        filter_row.addWidget(self.btn_export)

        root.addLayout(filter_row)

        splitter = QSplitter(Qt.Vertical)

        table_wrap = QWidget()
        tv = QVBoxLayout(table_wrap)
        tv.setContentsMargins(0, 0, 0, 0)
        tv.setSpacing(8)

        self.tbl = QTableView()
        self.tbl.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tbl.setSelectionMode(QAbstractItemView.SingleSelection)
        self.tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.setSortingEnabled(False)

        self.model = QStandardItemModel(0, len(self.HEADERS), self)
        self.model.setHorizontalHeaderLabels(self.HEADERS)
        self.tbl.setModel(self.model)

        self.tbl.setColumnWidth(0, 60)
        self.tbl.setColumnWidth(1, 150)
        self.tbl.setColumnWidth(2, 90)
        self.tbl.setColumnWidth(3, 140)
        self.tbl.setColumnWidth(4, 120)
        self.tbl.setColumnWidth(5, 160)
        self.tbl.setColumnWidth(6, 140)
        self.tbl.setColumnWidth(7, 360)
        self.tbl.setColumnWidth(8, 60)
        self.tbl.setColumnWidth(9, 90)
        self.tbl.setColumnWidth(10, 70)
        self.tbl.horizontalHeader().setStretchLastSection(True)

        tv.addWidget(self.tbl, 1)
        splitter.addWidget(table_wrap)

        viewer_wrap = QWidget()
        vv = QVBoxLayout(viewer_wrap)
        vv.setContentsMargins(0, 0, 0, 0)
        vv.setSpacing(8)

        viewer_title_row = QHBoxLayout()
        viewer_title_row.setSpacing(8)

        viewer_title_row.addWidget(QLabel("내용 보기(리포트/파일/상세)"), 0)

        self.btn_open_log_file = QPushButton("로그 파일 열기")
        self.btn_open_wipe_log = QPushButton("전체삭제 로그 보기")
        self.btn_show_selected_detail = QPushButton("선택 행 상세 보기")
        viewer_title_row.addStretch(1)
        viewer_title_row.addWidget(self.btn_show_selected_detail)
        viewer_title_row.addWidget(self.btn_open_wipe_log)
        viewer_title_row.addWidget(self.btn_open_log_file)

        vv.addLayout(viewer_title_row)

        self.txt_log_view = QTextEdit()
        self.txt_log_view.setReadOnly(True)
        self.txt_log_view.setPlaceholderText(
            "1) 상단 '발송 리포트 파일' 선택 → 가운데 표에 리포트 상세 표시\n"
            "2) 표 행 클릭 → 보낸 캠페인 미리보기(팝업)\n"
            "3) '선택 행 상세 보기'로 행 상세 확인\n"
        )
        vv.addWidget(self.txt_log_view, 1)

        splitter.addWidget(viewer_wrap)
        splitter.setStretchFactor(0, 7)
        splitter.setStretchFactor(1, 3)

        root.addWidget(splitter, 1)

        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)

        self.btn_retry = QPushButton("재시도(실패 대상 목록 추출)")
        btn_row.addWidget(self.btn_retry)

        btn_row.addStretch(1)

        self.reset_btn = QPushButton("전체 삭제 (send_logs + 리포트 초기화)")
        self.reset_btn.setStyleSheet("background:#fee2e2; color:#b91c1c;")
        btn_row.addWidget(self.reset_btn)

        self.btn_reset_all = QPushButton("전체 리셋 (로컬 데이터 삭제 후 종료)")
        self.btn_reset_all.setStyleSheet("background:#dc2626; color:#ffffff; font-weight:700;")
        self.btn_reset_all.setEnabled(self._on_reset_all is not None)
        btn_row.addWidget(self.btn_reset_all)

        root.addLayout(btn_row)

        self.btn_refresh.clicked.connect(self.refresh)
        self.btn_fail_only.clicked.connect(self._set_fail_only)
        self.btn_export.clicked.connect(self.export_csv)
        self.reset_btn.clicked.connect(self.reset_logs_and_reports)
        self.btn_retry.clicked.connect(self.show_retry_targets)

        self.btn_open_log_file.clicked.connect(self.open_log_file)
        self.btn_open_wipe_log.clicked.connect(self.open_wipe_log)
        self.btn_show_selected_detail.clicked.connect(self.show_selected_detail)
        self.btn_reset_all.clicked.connect(self.reset_all_app)

        self.cbo_status.currentIndexChanged.connect(lambda _: self.refresh())
        self.txt_keyword.returnPressed.connect(self.refresh)
        self.tbl.selectionModel().selectionChanged.connect(lambda *_: self._auto_show_reason_preview())
        self.tbl.clicked.connect(self._on_table_clicked)
        self.tbl.doubleClicked.connect(self._on_table_double_clicked)

        self.btn_reports_refresh.clicked.connect(self.refresh_reports)
        self.cbo_reports.currentIndexChanged.connect(lambda _: self.open_selected_report())

        self.refresh_reports()
        self.refresh()

    def _reports_dir(self) -> Path:
        d = Path(user_data_dir()) / "Reports"
        d.mkdir(parents=True, exist_ok=True)
        return d

    def _current_status(self) -> Optional[str]:
        value = self.cbo_status.currentData()
        return str(value) if value else None

    def _current_keyword(self) -> str:
        return (self.txt_keyword.text() or "").strip()

    def refresh_reports(self) -> None:
        self.cbo_reports.blockSignals(True)
        self.cbo_reports.clear()
        self.cbo_reports.addItem("(리포트 선택: 선택 시 표에 상세 표시)", None)

        files = sorted(
            self._reports_dir().glob("send_report_*.json"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )

        for path in files[:500]:
            try:
                ts = datetime.fromtimestamp(path.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S")
                label = f"{path.name}  ({ts})"
            except Exception:
                label = path.name
            self.cbo_reports.addItem(label, str(path))

        self.cbo_reports.blockSignals(False)

    def open_selected_report(self) -> None:
        self.cbo_reports.blockSignals(True)
        try:
            raw_path = self.cbo_reports.currentData()
        finally:
            self.cbo_reports.blockSignals(False)

        if not raw_path:
            self._switch_to_db_mode()
            self.refresh()
            return

        path = Path(str(raw_path))
        if not path.exists():
            QMessageBox.information(self, "안내", "리포트 파일이 존재하지 않습니다.")
            return

        try:
            report_rows = self.logs_service.load_report_rows(path)
        except Exception as e:
            QMessageBox.critical(self, "오류", f"리포트 로드 실패\n{path}\n\n{e}")
            return

        self._active_source = "REPORT"
        self._report_path = path
        self._report_rows = report_rows

        self.txt_log_view.setPlainText(
            f"[SEND REPORT]\n- file: {str(path)}\n\n"
            "✅ 표는 리포트 상세로 전환되었습니다.\n"
            "✅ 표 행 클릭 → 보낸 캠페인 미리보기(팝업)\n"
        )

        self.refresh()

    def _switch_to_db_mode(self) -> None:
        self._active_source = "DB"
        self._report_path = None
        self._report_rows = []
        self._shown_rows = []
        self.txt_log_view.setPlainText("DB 로그 모드로 전환되었습니다.")

    def _get_filtered_report_rows(self) -> List[Dict[str, Any]]:
        return self.logs_service.filter_report_rows(
            self._report_rows,
            status=self._current_status(),
            keyword=self._current_keyword(),
        )

    def _get_db_rows(self, *, limit: int, offset: int = 0) -> List[Dict[str, Any]]:
        return self.logs_service.list_log_rows(
            status=self._current_status(),
            keyword=self._current_keyword(),
            limit=limit,
            offset=offset,
        )

    def _render_rows_to_table(self, rows: List[Dict[str, Any]]) -> None:
        self.model.setRowCount(0)
        self._shown_rows = list(rows)

        for row in rows:
            self.model.appendRow(
                [
                    self._item(row.get("id", "")),
                    self._item(row.get("ts", "")),
                    self._item(row.get("campaign_id", "")),
                    self._item(row.get("batch_id", "")),
                    self._item(row.get("channel", "")),
                    self._item(row.get("recipient", "")),
                    self._item(row.get("status", "")),
                    self._item(row.get("reason", "")),
                    self._item(row.get("attempt", "")),
                    self._item(row.get("message_len", "")),
                    self._item(row.get("image_count", "")),
                ]
            )

        self._auto_show_reason_preview()

    def _item(self, value: object) -> QStandardItem:
        item = QStandardItem("" if value is None else str(value))
        item.setEditable(False)
        return item

    def _on_table_clicked(self, index: QModelIndex) -> None:
        if self._active_source != "REPORT":
            return
        self._open_campaign_preview_for_row(index.row())

    def _on_table_double_clicked(self, index: QModelIndex) -> None:
        if not index.isValid():
            return

        row = index.row()
        detail: Dict[str, Any] = {}

        if self._active_source == "REPORT":
            if 0 <= row < len(self._shown_rows):
                report_row = dict(self._shown_rows[row])
                list_meta = report_row.get("_list_meta") if isinstance(report_row.get("_list_meta"), dict) else {}
                detail = {
                    "ts": report_row.get("ts", ""),
                    "channel": report_row.get("channel", ""),
                    "recipient": report_row.get("recipient", ""),
                    "status": report_row.get("status", ""),
                    "reason": report_row.get("reason", ""),
                    "attempt": report_row.get("attempt", ""),
                    "message_len": report_row.get("message_len", ""),
                    "image_count": report_row.get("image_count", ""),
                    "campaign_id": report_row.get("campaign_id", ""),
                    "campaign_name": report_row.get("_campaign_name", ""),
                    "campaign_title": f"{report_row.get('_group_name', '')} + {report_row.get('_campaign_name', '')}".strip(" +"),
                    "campaign_items": (list_meta.get("campaign_items") or []),
                }
        else:
            selected = self._selected_row_values()
            if not selected:
                return
            detail = {
                "ts": selected.get("ts", ""),
                "channel": selected.get("channel", ""),
                "recipient": selected.get("recipient", ""),
                "status": selected.get("status", ""),
                "reason": selected.get("reason", ""),
                "attempt": selected.get("attempt", ""),
                "message_len": selected.get("message_len", ""),
                "image_count": selected.get("image_count", ""),
                "campaign_id": selected.get("campaign_id", ""),
                "campaign_name": "(DB 로그) 캠페인명 미기록",
                "campaign_title": str(selected.get("channel", "") or "캠페인"),
            }

        from frontend.pages.logs.detail_dialog import LogDetailDialog

        dlg = LogDetailDialog(
            title="발송 상세",
            detail=detail,
            campaigns_service=self.campaigns_service,
            parent=self,
        )
        dlg.exec()

    def _items_need_bytes(self, items: List[Any]) -> bool:
        for item in items:
            if isinstance(item, dict):
                if str(item.get("item_type", "")).upper() != "IMAGE":
                    continue
                image_bytes = item.get("image_bytes", None)
                if isinstance(image_bytes, (bytes, bytearray)) and len(image_bytes) > 0:
                    continue
                return True

            item_type = str(getattr(item, "item_type", "") or "").upper()
            if item_type != "IMAGE":
                continue
            image_bytes = getattr(item, "image_bytes", None)
            if isinstance(image_bytes, (bytes, bytearray)) and len(image_bytes) > 0:
                continue
            return True

        return False

    def _open_campaign_preview_for_row(self, row: int) -> None:
        if row < 0 or row >= len(self._shown_rows):
            return

        report_row = self._shown_rows[row]
        list_meta = report_row.get("_list_meta")
        if not isinstance(list_meta, dict):
            QMessageBox.information(self, "안내", "캠페인 정보가 없습니다.")
            return

        items = list_meta.get("campaign_items") or []
        if not isinstance(items, list) or not items:
            QMessageBox.information(self, "안내", "리포트에 캠페인 내용이 없습니다.")
            return

        campaign_id = list_meta.get("campaign_id")
        if self._items_need_bytes(items) and self.campaigns_service and campaign_id is not None:
            try:
                items_db = self.campaigns_service.get_campaign_items(int(campaign_id))
                if items_db:
                    items = items_db
            except Exception as e:
                QMessageBox.warning(self, "경고", f"캠페인 이미지 로드(재조회) 실패\n{e}")

        group_name = str(list_meta.get("group_name", "") or "전체")
        campaign_name = str(list_meta.get("campaign_name", "") or "(캠페인)")
        title = f"{group_name} + {campaign_name}".strip(" +")

        dlg = CampaignPreviewDialog(campaign_title=title, items=items, parent=self)
        dlg.exec()

    def _set_fail_only(self) -> None:
        for i in range(self.cbo_status.count()):
            if self.cbo_status.itemData(i) == "FAIL":
                self.cbo_status.setCurrentIndex(i)
                return

    def refresh(self) -> None:
        try:
            if self._active_source == "REPORT":
                rows = self._get_filtered_report_rows()
            else:
                rows = self._get_db_rows(limit=2000, offset=0)
        except Exception as e:
            QMessageBox.critical(self, "오류", f"로그 로드 실패\n{e}")
            return

        self._render_rows_to_table(rows)

    def export_csv(self) -> None:
        if self._active_source == "REPORT":
            rows = self._get_filtered_report_rows()
            default_path = Path.home() / "send_report_rows.csv"
            dialog_title = "CSV 저장(리포트)"
        else:
            try:
                rows = self._get_db_rows(limit=50000, offset=0)
            except Exception as e:
                QMessageBox.critical(self, "오류", f"CSV 내보내기용 로그 로드 실패\n{e}")
                return
            default_path = Path.home() / "send_logs.csv"
            dialog_title = "CSV 저장"

        file_path, _ = QFileDialog.getSaveFileName(
            self,
            dialog_title,
            str(default_path),
            "CSV Files (*.csv)",
        )
        if not file_path:
            return

        try:
            with open(file_path, "w", newline="", encoding="utf-8-sig") as f:
                writer = csv.writer(f)
                writer.writerow(
                    [
                        "id",
                        "ts",
                        "campaign_id",
                        "batch_id",
                        "channel",
                        "recipient",
                        "status",
                        "reason",
                        "attempt",
                        "message_len",
                        "image_count",
                    ]
                )
                for row in rows:
                    writer.writerow(
                        [
                            row.get("id", ""),
                            row.get("ts", ""),
                            row.get("campaign_id", ""),
                            row.get("batch_id", ""),
                            row.get("channel", ""),
                            row.get("recipient", ""),
                            row.get("status", ""),
                            row.get("reason", ""),
                            row.get("attempt", 0),
                            row.get("message_len", 0),
                            row.get("image_count", 0),
                        ]
                    )
        except Exception as e:
            QMessageBox.critical(self, "오류", f"CSV 저장 실패\n{e}")
            return

        QMessageBox.information(self, "완료", f"CSV 저장 완료\n{file_path}")

    def show_retry_targets(self) -> None:
        if self._active_source == "REPORT":
            rows = self._get_filtered_report_rows()
            targets = self.logs_service.get_retry_targets_from_rows(
                rows,
                fail_prefix="FAIL",
            )
            if not targets:
                QMessageBox.information(self, "안내", "리포트 기준 FAIL 대상이 없습니다.")
                return

            preview = "\n".join(targets[:80])
            if len(targets) > 80:
                preview += f"\n… (+{len(targets) - 80}명)"

            QMessageBox.information(self, "재시도 대상(리포트 FAIL)", preview)
            return

        try:
            targets = self.logs_service.get_retry_targets()
        except Exception as e:
            QMessageBox.critical(self, "오류", f"재시도 대상 추출 실패\n{e}")
            return

        if not targets:
            QMessageBox.information(self, "안내", "재시도 대상(FAIL)이 없습니다.")
            return

        preview = "\n".join(targets[:80])
        if len(targets) > 80:
            preview += f"\n… (+{len(targets) - 80}명)"

        QMessageBox.information(self, "재시도 대상(FAIL)", preview)

    def reset_logs_and_reports(self) -> None:
        ok = QMessageBox.question(
            self,
            "전체 삭제",
            "1) send_logs 테이블 초기화\n"
            "2) send_report_*.json 리포트 파일 전체 삭제\n\n"
            "계속하시겠습니까?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if ok != QMessageBox.Yes:
            return

        try:
            self.logs_service.reset_all()
        except Exception as e:
            QMessageBox.critical(self, "오류", f"send_logs 초기화 실패\n{e}")
            return

        deleted = 0
        failed: List[str] = []

        try:
            for path in list(self._reports_dir().glob("send_report_*.json")):
                try:
                    path.unlink(missing_ok=True)
                    deleted += 1
                except Exception:
                    failed.append(path.name)
        except Exception as e:
            QMessageBox.warning(self, "경고", f"리포트 파일 삭제 중 오류\n{e}")

        self._switch_to_db_mode()
        self.refresh_reports()
        self.cbo_reports.setCurrentIndex(0)
        self.model.setRowCount(0)
        self.txt_log_view.setPlainText("초기화 완료. DB 로그 모드입니다.")
        self.refresh()

        QMessageBox.information(
            self,
            "완료",
            f"초기화 완료\n- send_logs 초기화 완료\n- 리포트 삭제: {deleted}개"
            + (f"\n- 삭제 실패: {len(failed)}개" if failed else "")
        )

    def _selected_row_values(self) -> Optional[dict]:
        idx = self.tbl.currentIndex()
        if not idx.isValid():
            return None

        row = idx.row()

        def g(col: int) -> str:
            item = self.model.item(row, col)
            return "" if item is None else (item.text() or "")

        return {
            "id": g(0),
            "ts": g(1),
            "campaign_id": g(2),
            "batch_id": g(3),
            "channel": g(4),
            "recipient": g(5),
            "status": g(6),
            "reason": g(7),
            "attempt": g(8),
            "message_len": g(9),
            "image_count": g(10),
        }

    def _auto_show_reason_preview(self) -> None:
        data = self._selected_row_values()
        if not data:
            return

        reason = (data.get("reason") or "").strip()
        if reason:
            self.txt_log_view.setPlainText(reason)
            return

        if self._active_source == "REPORT":
            self.txt_log_view.setPlainText(
                "사유(reason)가 비어있습니다.\n"
                "행 더블클릭 → 상세 팝업에서 전체 스냅샷 확인 가능\n"
                "행 클릭 → 캠페인 미리보기(리포트에 이미지 bytes가 없으면 DB 재조회)\n"
            )

    def show_selected_detail(self) -> None:
        data = self._selected_row_values()
        if not data:
            QMessageBox.information(self, "안내", "상세를 볼 행을 선택하세요.")
            return

        detail = (
            f"[ROW DETAIL]\n"
            f"- source: {self._active_source}\n"
            f"- id: {data['id']}\n"
            f"- ts: {data['ts']}\n"
            f"- campaign_id: {data['campaign_id']}\n"
            f"- batch_id: {data['batch_id']}\n"
            f"- channel: {data['channel']}\n"
            f"- recipient: {data['recipient']}\n"
            f"- status: {data['status']}\n"
            f"- attempt: {data['attempt']}\n"
            f"- message_len: {data['message_len']}\n"
            f"- image_count: {data['image_count']}\n\n"
            f"[reason]\n{data['reason']}\n"
        )
        self.txt_log_view.setPlainText(detail)

    def open_log_file(self) -> None:
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "로그 파일 열기",
            str(user_data_dir()),
            "Log Files (*.log *.txt *.jsonl *.json *.csv);;All Files (*)",
        )
        if not file_path:
            return
        self._load_text_file(Path(file_path))

    def open_wipe_log(self) -> None:
        try:
            import tempfile

            temp_dir = Path(tempfile.gettempdir())
            name = (user_data_dir().name or "app")
            wipe_log = temp_dir / f"{name}_wipe.log"
        except Exception as e:
            QMessageBox.critical(self, "오류", f"wipe 로그 경로 계산 실패\n{e}")
            return

        if not wipe_log.exists():
            QMessageBox.information(self, "안내", f"wipe 로그 파일이 없습니다.\n{wipe_log}")
            return

        self._load_text_file(wipe_log)

    def _load_text_file(self, path: Path) -> None:
        try:
            max_bytes = 5 * 1024 * 1024
            size = path.stat().st_size
            if size <= max_bytes:
                text = path.read_text(encoding="utf-8", errors="replace")
            else:
                with open(path, "rb") as f:
                    raw = f.read(max_bytes)
                text = raw.decode("utf-8", errors="replace")
                text += f"\n\n... (truncated, file_size={size} bytes)"
        except Exception as e:
            QMessageBox.critical(self, "오류", f"파일 로드 실패\n{path}\n\n{e}")
            return

        header = f"[FILE]\n{str(path)}\n\n"
        self.txt_log_view.setPlainText(header + text)

    def reset_all_app(self) -> None:
        if not self._on_reset_all:
            QMessageBox.information(self, "안내", "전체 리셋 기능이 연결되어 있지 않습니다.")
            return
        try:
            self._on_reset_all()
        except Exception as e:
            QMessageBox.critical(self, "오류", f"전체 리셋 실행 실패\n{e}")


__all__ = ["LogsPage"]